#!/bin/bash

nbc -d tests/test_couleur.nxc
nbc -d tests/test_leftmotor.nxc
nbc -d tests/test_rightmotor.nxc
nbc -d tests/test_poussoir.nxc
nbc -d tests/test_tachydroit.nxc
nbc -d tests/test_tachygauche.nxc
nbc -d tests/test_us.nxc
nbc -d rouge.nxc
nbc -d bleu.nxc
